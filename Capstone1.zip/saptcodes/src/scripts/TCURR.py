from pyrfc import Connection, ABAPApplicationError, ABAPRuntimeError, \
LogonError, CommunicationError
from configparser import ConfigParser
from pprint import PrettyPrinter
import docx
import os
import sys, json
if __name__ == "__main__" :

    ASHOST='10.47.41.47'
    CLIENT='100'
    SYSNR='01'
    USER='VIVEK'
    PASSWD='Initial$1'
    conn = Connection(ashost=ASHOST, sysnr=SYSNR, client=CLIENT, user=USER, passwd=PASSWD)



    try:

        #options = [{ 'TEXT': "PROFILE = 'SAP_ALL'", 'TEXT': "BNAME = '*'"}]
        options = [{ 'TEXT': "PROFILE = 'SAP_ALL'"}]
        #BNAME
        pp = PrettyPrinter(indent=4)
        ROWS_AT_A_TIME = 10
        rowskips = 0

        print("----Begin of Batch---")
        #result = conn.call('RFC_READ_TABLE', \
        #QUERY_TABLE = 'TPFET', \
        #OPTIONS = options, \
        #ROWSKIPS = rowskips, ROWCOUNT = ROWS_AT_A_TIME)
        result = conn.call('RFC_READ_TABLE', QUERY_TABLE='UST04', OPTIONS=options, ROWSKIPS=rowskips, ROWCOUNT=ROWS_AT_A_TIME)
        #result = conn.call('RFC_READ_TABLE', QUERY_TABLE='TCURR', OPTIONS=options, ROWSKIPS=rowskips,
        #                   ROWCOUNT=ROWS_AT_A_TIME, encoding = 'unicode_escape')
        pp.pprint(result['DATA'])

        rowskips += ROWS_AT_A_TIME
        mydoc = docx.Document()
        mydoc.add_paragraph(json.dumps(result['DATA']))
        data = json.dumps(result['DATA'])
        filepathname = os.path.dirname(sys.argv[0]) + "vulnerability.docx"
        mydoc.save(filepathname)


    except CommunicationError:
        print("Could not connect to server.")
        raise
    except LogonError:
        print("Could not log in. Wrong credentials?")
        raise
    except (ABAPApplicationError, ABAPRuntimeError):
        print("An error occurred.")
        raise
