import datetime

from docx.shared import Cm, Inches
from pyrfc import Connection
from pprint import pprint
from configparser import ConfigParser
from docx.text.paragraph import Paragraph

import docx

import collections


def main():
    config = ConfigParser()
    config.read("sapnwrfc.cfg")
    params_connection = config._sections[
        "connection"
    ]
    d = {}
    with open('Input_Parameters.txt') as f:
        lines = [line.rstrip() for line in f]

    dict1 = collections.defaultdict(list)
    for word in lines:
        dict1[word] = []

    with open('standard_values.txt') as f:
        lines = [line.rstrip() for line in f]
    groupPairsByKey = collections.defaultdict(list)
    for word in lines:
        wordPair = list(word.split(';'))

        for _ in (number + 1 for number in range(len(wordPair) - 1)):
            if wordPair[0] in groupPairsByKey:
                groupPairsByKey.setdefault(wordPair[0], []).append(wordPair[_])

            else:
                groupPairsByKey[wordPair[0]] = [wordPair[_]]

    conn = Connection(**params_connection)

    for key in dict1.keys():
        userdefined = conn.call("SBUF_PARAMETER_GET", PARAMETER_NAME = key)

        dict1[key].append(userdefined['PARAMETER_VALUE'])

    final_dict =  collections.defaultdict(list)
    #Header_List = ['Parameter', 'User Defined Value', 'Standard Value', 'Status']
    #final_dict['Header'] = Header_List
    for key in dict1:
        if key in groupPairsByKey:
            final_dict[key] = [key]
            final_dict[key].append(dict1[key][0])
            final_dict[key].append(groupPairsByKey[key][0])
            if ((dict1[key][0]) ==  (groupPairsByKey[key][0]) ):
               final_dict[key].append(groupPairsByKey[key][1])
            elif ( dict1[key][0].find('/usr/sap/') != -1 ) :
               final_dict[key].append(groupPairsByKey[key][1])
            else:
               final_dict[key].append('Vulnerable')
    output_doc(final_dict)

def sql_call(query):
    

def output_doc(final_dict):

    doc = docx.Document()

    # Add a Title to the document
    doc.add_heading('Application Server Vulnerability List', 0)

    date_time = datetime.datetime.now()
    doc.add_paragraph (date_time.strftime("%m/%d/%Y, %H:%M:%S"))

    # Creating a table object
    table = doc.add_table(rows=1, cols=4)
    row = table.rows[0].cells
    row[0].text = 'Parameter'
    row[1].text = 'User Defined Value'
    row[2].text = 'Standard Value'
    row[3].text = 'Status'

    # Adding data from the list to the table
    for key in final_dict:
        # Adding a row and then adding data in it.
        row = table.add_row().cells
        row[0].text = final_dict[key][0]
        row[1].text = final_dict[key][1]
        row[2].text = final_dict[key][2]
        row[3].text = final_dict[key][3]

        # Adding style to a table
    table.style = 'Colorful List'
    table.autofit = False
    table.allow_autofit = False
    table.columns[0].width = Inches(2.5)
    table.rows[0].cells[0].width = Inches(2.0)

    # Now save the document to a location
    doc.save('Application Server Vulnerability List.docx')




if __name__ == "__main__":
    main()