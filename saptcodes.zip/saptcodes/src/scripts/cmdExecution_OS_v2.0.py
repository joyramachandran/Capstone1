import datetime

from docx.shared import Cm, Inches

from pprint import pprint
from configparser import ConfigParser
import paramiko
import numpy as np
import pandas as pd
from tabulate import tabulate
import dataframe_image as dfi


from docx.text.paragraph import Paragraph
import docx
import collections
import json
import requests

class main():
    def __init__(self,server='os'):
        self.config = ConfigParser()
        self.config.read('sapnwrfc.cfg')
        params_connection = self.config._sections[server]

        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(self.config.get(server, 'address'),  self.config.get(server, 'port'), self.config.get(server, 'user'),  self.config.get(server, 'password'))

    def create_doc(self,filename):

        doc =   docx.Document()
        self.save_doc(doc,filename)


    def save_doc(self,doc,filename):

        # Now save the document to a location
        filepath = filename + ".docx"
        doc.save(filepath)

    def get_cve(self,snote):
        if (snote != ''):

            url = "https://services.nvd.nist.gov/rest/json/cves/1.0?keyword=/notes/" + snote +"&isExactMatch=true"
            response = requests.get(url)
            json_data = json.loads(response.content)


            if (json_data['totalResults'] > 0):

                CVE_ID = (json_data['result']['CVE_Items'][0]['cve']['CVE_data_meta']['ID'])
                #CVE_DESC = (json_data['result']['CVE_Items'][0]['cve']['description']['description_data'][0]['value'])
            else:
                CVE_ID = ''
                #CVE_DESC = ''
        else:
            CVE_ID = ''
            #CVE_DESC = ''

        return CVE_ID



    def command(self,filename,heading,cmd):


        stdin, stdout, stderr = self.ssh.exec_command(cmd)
        outlines = stdout.readlines()
        resp = ''.join(outlines)
        #print(resp)
        #doc = docx.Document()
        file = filename + ".docx"
        doc = docx.Document(file)

        doc.add_heading(heading, 1).bold = True

        cmdstring = "Command: " + cmd

        # Adding a paragraph

        date_time = datetime.datetime.now()
        doc.add_paragraph(date_time.strftime("%m/%d/%Y, %H:%M:%S"))
        logged_id = "Logged using user id: " + self.config.get('os', 'user')
        system_id = "System ip: " + self.config.get('os', 'address')
        doc.add_paragraph(logged_id)
        doc.add_paragraph(system_id)

        doc.add_heading(cmdstring, 3).bold = True

        doc.add_heading('Results:', 3).bold = True

        doc.add_paragraph(resp)

        self.save_doc(doc, filename)


if __name__ == "__main__":
    p = main()

    p.create_doc('OS Cmd Execution List')

    df = pd.read_excel('DBTS_VulnerabilityList_Read.xlsx', sheet_name='ConnectionTesting_Lowtouch')

    rslt_df = df[df['TypeOfAssessment'].isin(['LowTouch'])]


    for index, row in rslt_df.iterrows():
        # print(row['Vulnerability_Title'])
        results = p.command('OS Cmd Execution List', row['Execution_Title'], row['Command'])
