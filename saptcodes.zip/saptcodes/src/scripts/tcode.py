import sys
sys.path.append('../')

from utility.utility import let_user_pick

if __name__ == "__main__" :

	let_user_pick()